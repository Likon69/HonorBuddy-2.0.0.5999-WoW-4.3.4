﻿namespace Zerfall.Talents
{
    public enum WarlockTalentSpec
    {
        Lowbie = 0,
        Affliction,
        Demonology,
        Destruction
    }
}
