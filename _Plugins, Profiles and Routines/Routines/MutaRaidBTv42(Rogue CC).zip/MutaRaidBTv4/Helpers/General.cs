﻿//////////////////////////////////////////////////
//                General.cs                    //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////

using System.Diagnostics;
using Styx;

namespace MutaRaidBT.Helpers
{
    static class General
    {
        static public Stopwatch mTimer = new Stopwatch();

        static General()
        {
            mTimer.Start();
        }

        static public void UpdateHelpers()
        {
            using (new FrameLock())
            {
                Target.Pulse();
                Area.Pulse();
                Rogue.Pulse();
                Focus.Pulse();
                Specials.Pulse();

                Target.EnsureValidTarget();
            }
        }
    }
}
