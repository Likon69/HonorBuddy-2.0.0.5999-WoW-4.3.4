﻿//////////////////////////////////////////////////
//               Delegates.cs                   //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////

using Styx.Logic.Pathing;
using Styx.WoWInternals.WoWObjects;

namespace MutaRaidBT.Helpers
{
    public delegate uint PoisonDelegate(object context);
    public delegate WoWPoint WoWPointDelegate(object context);
    public delegate WoWItem WoWItemDelegate(object context);
    public delegate WoWUnit WoWUnitDelegate(object context);
}
