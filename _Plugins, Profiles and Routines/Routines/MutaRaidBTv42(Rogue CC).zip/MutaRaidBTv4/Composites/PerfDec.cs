﻿//////////////////////////////////////////////////
//                PerfDec.cs                    //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////

using Styx;
using TreeSharp;
using Styx.Helpers;
using System.Drawing;

namespace MutaRaidBT.Composites
{
    class PerfDec : Decorator
    {
        public PerfDec(Composite child)
            : base(child)
        {
        }

        public override RunStatus Tick(object context)
        {
            // Wraps the entire tree in a framelock and ticks the tree. 
            // Responsible for debug text.

            using (new FrameLock())
            {
                Helpers.General.mTimer.Reset();
                Helpers.General.mTimer.Start();

                Logging.WriteDebug(Color.Orange, "START TICK");

                string locInfo = "Context:" + Helpers.Area.mLocation + " Spec:" + Helpers.Rogue.mCurrentSpec + " Level:" + StyxWoW.Me.Level;
                string resInfo = "CP:" + StyxWoW.Me.ComboPoints + " RCP:" + StyxWoW.Me.RawComboPoints + " Energy:" + Helpers.Rogue.mCurrentEnergy;
                string tarInfo = "NULL";
                string focInfo = "NULL";

                if (StyxWoW.Me.CurrentTarget != null)
                {
                    tarInfo = StyxWoW.Me.CurrentTarget.ToString();
                }

                if (Helpers.Focus.mFocusTarget != null)
                {
                    focInfo = Helpers.Focus.mFocusTarget.ToString();
                }

                Logging.WriteDebug(Color.DarkBlue, locInfo);
                Logging.WriteDebug(Color.DarkBlue, resInfo);
                Logging.WriteDebug(Color.DarkBlue, tarInfo);
                Logging.WriteDebug(Color.DarkBlue, focInfo);

                RunStatus tick = base.Tick(context);

                Logging.WriteDebug(Color.Orange, "END TICK -> {0} ms", Helpers.General.mTimer.ElapsedMilliseconds);

                return tick;
            }
        }
    }
}