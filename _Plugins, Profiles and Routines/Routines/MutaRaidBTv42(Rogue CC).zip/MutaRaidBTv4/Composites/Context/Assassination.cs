﻿//////////////////////////////////////////////////
//              Assassination.cs                //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////

using TreeSharp;

namespace MutaRaidBT.Composites.Context
{
    static class Assassination
    {
        static public Composite BuildCombatBehavior()
        {
            return new Decorator(ret => Settings.Mode.mUseCombat,
                new Switch<Helpers.Enum.LocationContext>(ret => Helpers.Area.mLocation,

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Raid,
                        Raid.Assassination.BuildCombatBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.HeroicDungeon,
                        Raid.Assassination.BuildCombatBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Dungeon,
                        Level.Assassination.BuildCombatBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Battleground,
                        Battleground.Assassination.BuildCombatBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.World,
                        Level.Assassination.BuildCombatBehavior()
                    )
                )
            );
        }

        static public Composite BuildPullBehavior()
        {
            return new Decorator(ret => Settings.Mode.mUseCombat,
                new Switch<Helpers.Enum.LocationContext>(ret => Helpers.Area.mLocation,

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Raid,
                        Raid.Assassination.BuildPullBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.HeroicDungeon,
                        Raid.Assassination.BuildPullBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Dungeon,
                        Level.Assassination.BuildPullBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Battleground,
                        Battleground.Assassination.BuildPullBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.World,
                        Level.Assassination.BuildPullBehavior()
                    )
                )
            );
        }

        static public Composite BuildBuffBehavior()
        {
            return new Switch<Helpers.Enum.LocationContext>(ret => Helpers.Area.mLocation,

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Raid,
                        Raid.Assassination.BuildBuffBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.HeroicDungeon,
                        Raid.Assassination.BuildBuffBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Dungeon,
                        Level.Assassination.BuildBuffBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.Battleground,
                        Battleground.Assassination.BuildBuffBehavior()
                    ),

                    new SwitchArgument<Helpers.Enum.LocationContext>(Helpers.Enum.LocationContext.World,
                        Level.Assassination.BuildBuffBehavior()
                    )
            );
        }
    }
}
