﻿//////////////////////////////////////////////////
//           Battleground/Combat.cs             //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////

using TreeSharp;

namespace MutaRaidBT.Composites.Context.Battleground
{
    class Combat
    {
        // For now, just use the same behavior as our level context.

        static public Composite BuildCombatBehavior()
        {
            return new PrioritySelector(
                Helpers.Target.EnsureBestPvPTarget(),
                Level.Combat.BuildCombatBehavior()
            );
        }

        static public Composite BuildPullBehavior()
        {
            return Level.Combat.BuildPullBehavior();
        }

        static public Composite BuildBuffBehavior()
        {
            return Level.Combat.BuildBuffBehavior();
        }
    }
}
