﻿//////////////////////////////////////////////////
//                Shadowstep.cs                 //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////
// This is a blacklist of mobs which are        //
// considered unsafe to shadowstep to.          //
//////////////////////////////////////////////////

using System.Collections.Generic;

namespace MutaRaidBT.RaidSpecific
{
    class Shadowstep
    {
        static public HashSet<uint> Blacklist = new HashSet<uint>
        {
        };
    }
}
