﻿//////////////////////////////////////////////////
//                 Backstab.cs                  //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////
// This is a whitelist of mobs which are        //
// mechanically considered "always behind."     //
//////////////////////////////////////////////////

using System.Collections.Generic;

namespace MutaRaidBT.RaidSpecific
{
    class Backstab
    {
        static public HashSet<uint> Whitelist = new HashSet<uint>
        {

        };
    }
}
