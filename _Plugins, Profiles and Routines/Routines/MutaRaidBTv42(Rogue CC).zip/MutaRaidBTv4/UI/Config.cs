﻿//////////////////////////////////////////////////
//                Config.cs                     //
//      Part of MutaRaidBT by fiftypence        //
//////////////////////////////////////////////////

using System;
using System.Windows.Forms;

namespace MutaRaidBT.UI
{
    public partial class Config : Form
    {
        public Config()
        {
            InitializeComponent();
        }

        private void Config_Load(object sender, EventArgs e)
        {
            comboBoxRaidPoison1.DataSource      = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxRaidPoison2.DataSource      = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxHeroicPoison1.DataSource    = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxHeroicPoison2.DataSource    = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxDungeonPoison1.DataSource   = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxDungeonPoison2.DataSource   = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxBgPoison1.DataSource        = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxBgPoison2.DataSource        = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxLevelPoison1.DataSource     = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));
            comboBoxLevelPoison2.DataSource     = Enum.GetValues(typeof(Helpers.Enum.PoisonSpellId));

            checkBoxRaidPoison.Checked    = Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.Raid];
            checkBoxHeroicPoison.Checked  = Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.HeroicDungeon];
            checkBoxDungeonPoison.Checked = Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.Dungeon];
            checkBoxBgPoison.Checked      = Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.Battleground];
            checkBoxLevelPoison.Checked   = Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.World];

            comboBoxRaidPoison1.SelectedItem    = Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.Raid];
            comboBoxRaidPoison2.SelectedItem    = Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.Raid];
            comboBoxHeroicPoison1.SelectedItem  = Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.HeroicDungeon];
            comboBoxHeroicPoison2.SelectedItem  = Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.HeroicDungeon];
            comboBoxDungeonPoison1.SelectedItem = Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.Dungeon];
            comboBoxDungeonPoison2.SelectedItem = Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.Dungeon];
            comboBoxBgPoison1.SelectedItem      = Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.Battleground];
            comboBoxBgPoison2.SelectedItem      = Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.Battleground];
            comboBoxLevelPoison1.SelectedItem   = Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.World];
            comboBoxLevelPoison2.SelectedItem   = Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.World];

            panelRaidPoison.Enabled = checkBoxRaidPoison.Checked;
            panelHeroicPoison.Enabled = checkBoxHeroicPoison.Checked;
            panelDungeonPoison.Enabled = checkBoxDungeonPoison.Checked;
            panelBgPoison.Enabled = checkBoxBgPoison.Checked;
            panelLevelPoison.Enabled = checkBoxBgPoison.Checked;
     
            if (!Settings.Mode.mOverrideContext)
            {
                radioButtonAuto.Checked = true;
            }
            else
            {
                switch (Settings.Mode.mLocationSettings)
                {
                    case Helpers.Enum.LocationContext.Raid:

                        radioButtonRaid.Checked = true;
                        break;

                    case Helpers.Enum.LocationContext.HeroicDungeon:

                        radioButtonHeroicDungeon.Checked = true;
                        break;

                    case Helpers.Enum.LocationContext.Dungeon:

                        radioButtonDungeon.Checked = true;
                        break;

                    case Helpers.Enum.LocationContext.Battleground:

                        radioButtonBattleground.Checked = true;
                        break;

                    case Helpers.Enum.LocationContext.World:

                        radioButtonLevel.Checked = true;
                        break;
                }
            }

            if (Settings.Mode.mUseMovement)
            {
                radioButtonMoveOn.Checked = true;
            }
            else
            {
                radioButtonMoveOff.Checked = true;
            }

            if (Settings.Mode.mUseAoe)
            {
                radioButtonAoeOn.Checked = true;
            }
            else
            {
                radioButtonAoeOff.Checked = true;
            }

            switch (Settings.Mode.mCooldownUse)
            {
                case Helpers.Enum.CooldownUse.Always:

                    radioCooldownAlways.Checked = true;
                    break;

                case Helpers.Enum.CooldownUse.ByFocus:

                    radioCooldownByFocus.Checked = true;
                    break;

                case Helpers.Enum.CooldownUse.OnlyOnBosses:

                    radioCooldownByBoss.Checked = true;
                    break;

                case Helpers.Enum.CooldownUse.Never:

                    radioCooldownNever.Checked = true;
                    break;
            }
        }

        private void buttonApply_Click(object sender, EventArgs e)
        {
            if (checkBoxRaidPoison.Checked || checkBoxHeroicPoison.Checked)
            {
                var input = MessageBox.Show("WARNING: You have enabled poisons for Raid mode or Heroic Dungeon mode. Using Apoc's Raid Bot as your botbase will result in MutaRaidBT being " +
                                             "unable to apply poisons, regardless of context, due to a design limitation with Raid Bot. ",
                                             "Warning",
                                             MessageBoxButtons.OKCancel,
                                             MessageBoxIcon.Exclamation);

                if (input == DialogResult.Cancel) return;
            }

            Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.Raid]          = checkBoxRaidPoison.Checked;
            Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.HeroicDungeon] = checkBoxHeroicPoison.Checked;
            Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.Dungeon]       = checkBoxDungeonPoison.Checked;
            Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.Battleground]  = checkBoxBgPoison.Checked;
            Settings.Mode.mUsePoisons[(int) Helpers.Enum.LocationContext.World]         = checkBoxLevelPoison.Checked;

            Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.Raid]          = (Helpers.Enum.PoisonSpellId) comboBoxRaidPoison1.SelectedItem;
            Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.Raid]           = (Helpers.Enum.PoisonSpellId) comboBoxRaidPoison2.SelectedItem;
            Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.HeroicDungeon] = (Helpers.Enum.PoisonSpellId) comboBoxHeroicPoison1.SelectedItem;
            Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.HeroicDungeon]  = (Helpers.Enum.PoisonSpellId) comboBoxHeroicPoison2.SelectedItem;
            Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.Dungeon]       = (Helpers.Enum.PoisonSpellId) comboBoxDungeonPoison1.SelectedItem;
            Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.Dungeon]        = (Helpers.Enum.PoisonSpellId) comboBoxDungeonPoison2.SelectedItem;
            Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.Battleground]  = (Helpers.Enum.PoisonSpellId) comboBoxBgPoison1.SelectedItem;
            Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.Battleground]   = (Helpers.Enum.PoisonSpellId) comboBoxBgPoison2.SelectedItem;
            Settings.Mode.mPoisonsMain[(int) Helpers.Enum.LocationContext.World]         = (Helpers.Enum.PoisonSpellId) comboBoxLevelPoison1.SelectedItem;
            Settings.Mode.mPoisonsOff[(int) Helpers.Enum.LocationContext.World]          = (Helpers.Enum.PoisonSpellId) comboBoxLevelPoison2.SelectedItem;

            Settings.Mode.mOverrideContext = !radioButtonAuto.Checked;
            Settings.Mode.mUseMovement = radioButtonMoveOn.Checked;
            Settings.Mode.mUseAoe = radioButtonAoeOn.Checked;

            if (radioButtonRaid.Checked)
            {
                Settings.Mode.mLocationSettings = Helpers.Enum.LocationContext.Raid;
            }
            else if (radioButtonHeroicDungeon.Checked)
            {
                Settings.Mode.mLocationSettings = Helpers.Enum.LocationContext.HeroicDungeon;
            }
            else if (radioButtonDungeon.Checked)
            {
                Settings.Mode.mLocationSettings = Helpers.Enum.LocationContext.Dungeon;
            }
            else if (radioButtonBattleground.Checked)
            {
                Settings.Mode.mLocationSettings = Helpers.Enum.LocationContext.Battleground;
            }
            else if (radioButtonLevel.Checked)
            {
                Settings.Mode.mLocationSettings = Helpers.Enum.LocationContext.World;
            }

            if (radioCooldownAlways.Checked)
            {
                Settings.Mode.mCooldownUse = Helpers.Enum.CooldownUse.Always;
            }
            else if (radioCooldownByFocus.Checked)
            {
                Settings.Mode.mCooldownUse = Helpers.Enum.CooldownUse.ByFocus;
            }
            else if (radioCooldownByBoss.Checked)
            {
                Settings.Mode.mCooldownUse = Helpers.Enum.CooldownUse.OnlyOnBosses;  
            }
            else
            {
                Settings.Mode.mCooldownUse = Helpers.Enum.CooldownUse.Never;
            }

            Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonLaunchCombatControl_Click(object sender, EventArgs e)
        {
            var combatControl = new CombatControl();
            combatControl.Show();
        }

        private void checkBoxRaidPoison_CheckedChanged(object sender, EventArgs e)
        {
            panelRaidPoison.Enabled = checkBoxRaidPoison.Checked;
        }

        private void checkBoxHeroicPoison_CheckedChanged(object sender, EventArgs e)
        {
            panelHeroicPoison.Enabled = checkBoxHeroicPoison.Checked;
        }

        private void checkBoxDungeonPoison_CheckedChanged(object sender, EventArgs e)
        {
            panelDungeonPoison.Enabled = checkBoxDungeonPoison.Checked;
        }

        private void checkBoxBgPoison_CheckedChanged(object sender, EventArgs e)
        {
            panelBgPoison.Enabled = checkBoxBgPoison.Checked;
        }

        private void checkBoxLevelPoison_CheckedChanged(object sender, EventArgs e)
        {
            panelLevelPoison.Enabled = checkBoxBgPoison.Checked;
        }
    }
}
